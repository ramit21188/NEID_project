import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
import math as m

# Constants and parameters
rho_copper = 1.724e-8  # resistivity of copper wire in ohm-meters
mu_0 = 4 * np.pi * 1e-7  # permeability of free space in H/m
N_coil = 1 # number of turns in the coil
inner_diameter = 5e-3  # inner diameter of the coil in meters
radius_coil = inner_diameter / 2  # radius of the coil
length_wire = 2 * 3.14 * radius_coil  # length of the wire for a single-turn coil
length_wire_thick=inner_diameter
thickness_nerve = 0.6e-3  # nerve thickness in meters

# Convert AWG to diameter in meters
def awg_to_diameter(awg):
    diameter_inch = 0.005 * 92**((36 - awg) / 39)
    diameter_meter = diameter_inch *0.0254  # Convert inches to meters
    return diameter_meter

# Calculate the diameter of 22 AWG wire
diameter_22_awg = awg_to_diameter(22)

# Calculate the cross-sectional area of the wire
A_wire = 3.14 * (diameter_22_awg / 2)**2  # cross-sectional area of 22 AWG wire in square meters

# Calculate the resistance of the wire (R_wire)
R_ = (N_coil*(rho_copper * length_wire) )/ A_wire  # resistance of the wire
print("resistance",R_)
a=diameter_22_awg/2
R=radius_coil

# Calculate the inductance of the coil (L_coil)
L_ =  (N_coil)**2*R*mu_0*(m.log((8*R)/a)-2.0) # inductance of the coil
print("inductance",L_)

# Capacitance
C_ = 5e-3  # capacitance in farads

# DC voltage source
V_dc = 400  # DC voltage source in volts

# End time for simulation
T_end = 5e-3  # End time for simulation in seconds

# Define the differential equation for the circuit
def circuit(t, y):
    i, di_dt = y
    di2_dt2 = -(R_/L_)*di_dt - (1/(L_*C_))*i
    return [di_dt, di2_dt2]

# Initial conditions
y0 = [0, V_dc/L_]

# Time points
t = np.linspace(0, T_end, 5001)

# Solve the differential equation
sol = solve_ivp(circuit, [0, T_end], y0, t_eval=t)

# Plot the solution
plt.figure(figsize=(12, 6))
Imax=np.max(sol.y[1])
solution=(sol.y[1]/np.max(sol.y[1]))
np.savetxt('dIdt_norm.txt', sol.y[1]/Imax, fmt='%.5e')


# Plot di/dt
plt.subplot(2, 1, 1)
plt.plot(sol.t, sol.y[1], label="di/dt", color='blue')
plt.xlabel('Time')
plt.ylabel('di/dt')
plt.legend()

# Plot i
plt.subplot(2, 1, 2)
plt.plot(sol.t, sol.y[0], label="I", color='red')
plt.xlabel('Time')
plt.ylabel('I')
plt.legend()

plt.tight_layout()
plt.show()
