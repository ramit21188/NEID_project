import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import math as m
from currento import *

    

 

def electric_F(points, radius):
    mu_0 = 4 * np.pi * 1e-7  # Permeability of free space
    di_dt = 6e10  # Example current change rate (A/s)
    Ex = 0
    Ey=[]
    X = np.linspace( -0.01, 0.01, 100)
    Y = np.linspace( -0.01, 0.01, 100)
    Z = np.zeros((len(X), len(Y)))
    l=len(points)
    dl=(2*3.14*radius)/l

  
    for i, x1 in enumerate(X):
        for j, y1 in enumerate(Y):
            E=0
            for e in points:
                x=e[0]
                y=e[1]
                z=e[2]
                r = m.sqrt((x1 - x) ** 2 + (y1 - y) ** 2 + z ** 2)
                
                E=E+((mu_0 *dl* -di_dt)*(y/radius)) / (4 * np.pi * r) #*(x/radius)    
                
                
                 
            Z[i, j] = E

    
    gradient = np.gradient(Z, axis=0)/np.gradient(X)

    fig = plt.figure(figsize=(12, 6))
    X, Y = np.meshgrid(X, Y)

    # Plot the electric field
    ax1 = fig.add_subplot(121, projection='3d')
    ax1.plot_surface(X, Y, Z, cmap='viridis')
    ax1.set_xlabel('X')
    ax1.set_ylabel('Y')
    ax1.set_zlabel('Electric Field')
    ax1.set_title('Electric Field due to Current Loop')

    # Plot the gradient along the x-direction
    ax2 = fig.add_subplot(122)
    im = ax2.imshow(gradient, cmap='viridis', origin='lower', extent=(-0.01 ,0.01 ,-0.01, 0.01))
    ax2.set_xlabel('X')
    ax2.set_ylabel('Y')
    ax2.set_title('Gradient of Electric Field along X-axis')
    fig.colorbar(im, ax=ax2, label='Gradient')

    plt.tight_layout()
    plt.show()
    x_value = 0.004

# Find the index closest to the specified y value
    idx = np.argmin(np.abs(X - x_value))

# Get the gradient at the specified y value
    gradient_at_x = gradient[idx, :]

# Print and save the gradient values at the specified y value
    print(f"Gradient at X = {x_value}:", gradient_at_x*1e-3 )
    np.savetxt('dEdX.txt', gradient_at_x *1e-3, fmt='%.5e')
    
   
    
    
    '''
    plt.figure()
    plt.contourf(X, Y, Z, cmap='viridis')
    plt.colorbar(label='Electric Field')
    plt.xlabel('Y')
    plt.ylabel('X')
    plt.title('Electric Field due to Current Loop along the X-axis')
    plt.show()'''


def create_ring(radius, height,t):
    points = []
    x = np.linspace(-10*radius, 10*radius, 1000)
    y = np.linspace(-10*radius, 10*radius, 1000)
    for e in x:
        for f in y:
            if (radius**2<((e)**2 + (f)**2) and ((e)**2 + (f)**2)<radius**2+t**2+2*radius*t):  # Check if point is inside the circle
                points.append((e, f, height))
    return points

radius = radius_coil
height = 0.5e-3  # Example height
print(radius)
th=diameter_22_awg
points = create_ring(radius, height,th)
# print(points)

# Unzip points into separate x, y, z arrays for plotting
x, y, z = zip(*points)

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.scatter(x, y, z)

ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.set_title('Ring at Height {}'.format(height))
plt.show()
electric_F(points, radius)
